#!/bin/bash

# I had some trouble finishing the assigment from here on.
# _package.sh, and _all.sh are empty as well.
