#!/bin/bash

./remove_comments_multi_line.sh  | ./remove_comments_single_line.sh
