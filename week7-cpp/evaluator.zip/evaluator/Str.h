#include <string>
#include <sstream>
#include <iostream>

class Str
{
public:

    Str()
    {
    }
        
private:
    std::string m_str;
};
